const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post('/api/triage', (req, res) => {
  const { symptoms } = req.body;
  let recommendation = "Further evaluation required.";

  if (symptoms.toLowerCase().includes("shortness of breath")) {
    recommendation = "Seek emergency care immediately.";
  } else if (symptoms.toLowerCase().includes("fever")) {
    recommendation = "Monitor at home. If fever persists, consult a physician.";
  }

  res.json({ recommendation });
});

app.listen(5000, () => console.log("Sentri-Link backend running on port 5000"));
