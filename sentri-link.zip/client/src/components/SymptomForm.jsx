import React, { useState } from 'react';
import axios from 'axios';

const SymptomForm = () => {
  const [symptoms, setSymptoms] = useState('');
  const [result, setResult] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await axios.post('http://localhost:5000/api/triage', { symptoms });
    setResult(res.data);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-4 rounded shadow">
      <label className="block font-semibold mb-2">Describe your symptoms:</label>
      <textarea
        className="w-full border rounded p-2"
        value={symptoms}
        onChange={(e) => setSymptoms(e.target.value)}
      />
      <button className="mt-3 bg-blue-600 text-white px-4 py-2 rounded">Submit</button>
      {result && (
        <div className="mt-4 p-3 bg-gray-100 rounded shadow">
          <strong>Recommendation:</strong> <p>{result.recommendation}</p>
        </div>
      )}
    </form>
  );
};

export default SymptomForm;
