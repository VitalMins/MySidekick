import React from 'react';
import SymptomForm from './components/SymptomForm';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-6">
      <h1 className="text-3xl font-bold text-blue-700 mb-4">Sentri-Link Triage System</h1>
      <SymptomForm />
    </div>
  );
}

export default App;
