# Sentri-Link

Smart home triage and medical teleconsultation system.